# Conky Clock

> Run `./install.sh` after installing conky

* Install the Product Sans font (install all variants!) from this link: https://befonts.com/download/product-sans

!["Screenshot"](Screenshot.png)

### Just a slight modification of  https://www.github.com/AweGuy22/simple-conky-clock
### Added am and pm 
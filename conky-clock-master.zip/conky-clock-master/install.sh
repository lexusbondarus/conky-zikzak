#!/bin/bash
echo "Adding conky.conf file"
mkdir -p ~/.config/conky/
cp conky.conf ~/.config/conky/
echo "Done"